package com.gg.gop.controller;

import org.springframework.stereotype.Controller;


@Controller
public class HomeController {


//	@GetMapping("/")
//	public String Main() {
//		return "index";
//	}

	
		
		//이전 사용했던 세션들을 끊어줌
	


}
