package com.gg.gop.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MainController {

//	@GetMapping("/")
//	public String Main() {
//		return "index";
//	}

}
