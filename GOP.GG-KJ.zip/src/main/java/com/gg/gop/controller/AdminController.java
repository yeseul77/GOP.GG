package com.gg.gop.controller;

import org.springframework.stereotype.Controller;

@Controller
public class AdminController {
	
	

}
