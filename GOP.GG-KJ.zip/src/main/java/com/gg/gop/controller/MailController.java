package com.gg.gop.controller;


import org.springframework.web.bind.annotation.RestController;

//이메일 인증번호 하는거 맹글어야함.. 
@RestController     ///("/sendEmailVerification")
public class MailController {
	


	          
	
	   

	}


