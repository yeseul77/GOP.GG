package com.gg.gop.service;

public class MailService {

}
